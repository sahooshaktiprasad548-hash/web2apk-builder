# Keep WebView JavaScript interfaces if added
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
